import React from 'react'
import logo from "./logo.jpg"

function Home() {
        

    return (
        <div>


            <h1 className='mb-3'>Sahyadri Hospital ,Karad </h1><br/>
           <hr/> 
            <img className='logo' src={logo} alt="LOGO"  width="30%" height="30%"  ></img>
            <hr/> 
            <h1>---Facilities---</h1>
            
            <h4 className='mb-3'> Operation Theatres</h4>
            <label>Emergency control</label>
            <h4> Test Labs</h4>
            <label>labs available for various tests</label>

             <h4>X-ray facility</h4>
             <label>Easy x-ray facility</label>

            <h4>Ventilators</h4>
            <label>ventilators available for needed</label>
            

            <h4>Blood bank</h4>
            <label>blood bank available for emergency situations</label>
            <h4> charity program</h4>
            <label>schemes available for financial aid</label>
            </div>
    )
}

export default Home