import React from 'react'

function Services() {
    return (
        <div>
             <h1 className='mb-3'>Sahyadri Hospital, Karad</h1>
             <h4>Patient Treated : 450000</h4>
             <h4>Cancer patients treated : 3500</h4>

             <h4>Patient availed charity : 53   </h4>
             <br/>
<hr/>
             <h2 className='mb-3'>Admission</h2>
             <h4>Address : Kolhapur naka,Karad</h4>
             <h4>Pin Code : 416406</h4>
             
             <h4>Parking facility available</h4>
             
        </div>
    )
}

export default Services
