import React from 'react'

function About() {
    return (
        <div>
         K.E. Society's <br/>

Sahyadri Hospital , karad, Tal. karad, Dist. Satara,<br/>

Maharashtra, India - 416406.<br/>

E-Mail : sahyadrihospital@gmail.com<br/>
Tel : - +91 - 2342 – 220329, 9970700700, <br/>For MBA : 226488, , 9970700810<br/>

Fax : - +91 - 2342 – 220989
        </div>
    )
}

export default About
