import React from 'react'

function Services() {
    return (
        <div>
             <h1 className='mb-3'>Rajarampabu institute of  Techenology Islampur Previous Year Placement</h1>
             <h4>Average Packege : 4.5LPA</h4>
             <h4>Highest  Packege : 12LPA</h4>

             <h4>Number student qulified GRE : 56   </h4>
             <br/>
<hr/>
             <h2 className='mb-3'>Admission</h2>
             <h4>Admission open date : 01-01-2022</h4>
             <h4>Admission close date : 31-01-2022</h4>
             
             <h4>Hostel Admisson  close date : 17-01-2022</h4>
             
        </div>
    )
}

export default Services
