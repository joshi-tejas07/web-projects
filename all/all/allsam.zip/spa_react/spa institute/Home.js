import React from 'react'
import logo from "./logo.jpg"

function Home() {
        

    return (
        <div>


            <h1 className='mb-3'>Rajarampabu institute of  Techenology Islampur </h1><br/>
           <hr/> 
            <img className='logo' src={logo} alt="LOGO"  width="30%" height="30%"  ></img>
            <hr/> 
            <h1>---Department---</h1>
            
            <h4 className='mb-3'> Machanical Engineering </h4>
            <label>Strength : 150</label>
            <h4> Electrical Engineering</h4>
            <label>Strength : 80</label>

             <h4>Automobile Engineering</h4>
             <label>Strength : 80</label>

            <h4>Electronic and Telecummunication Engineering</h4>
            <label>Strength : 80</label>
            

            <h4>Compueter Engineering</h4>
            <label>Strength : 150</label>
            <h4> Information Techenology Engineering</h4>
            <label>Strength : 80</label>
            </div>
    )
}

export default Home