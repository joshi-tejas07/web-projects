import React, { Component } from "react";
 
class Stuff extends Component {
  render() {
    return (
      <div color="blue">
        <h2>STUFF</h2>
        <p>Front End Web Technology Lab</p>
        <ol color="blue">
          <li>Experiment No. 1</li>
          <li>Experiment No. 2</li>
          <li>Experiment No. 3</li>
          <li>Experiment No. 4</li>
          <li>Experiment No. 5</li>
        </ol>
      </div>
    );
  }
}
 
export default Stuff;