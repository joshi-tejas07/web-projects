import React, { Component } from "react";
 
class Home extends Component {
  render() {
    return (
      <center>
      <div >
        <h2>The National Pledge</h2>
        <p>India is my country and all Indians are my brothers and sisters.
I love my country and I am proud of its rich and varied heritage.
I shall always strive to be worthy of it.
I shall give respect to my parents, teachers and all elders and treat everyone with courtesy.
To my country and my people, I pledge my devotion. In their well-being and prosperity alone lies my happiness.</p>
      </div>
      </center>
    );
  }
}
 
export default Home;