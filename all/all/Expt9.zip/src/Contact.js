import React, { Component } from "react";
 
class Contact extends Component {
  render() {
    return (
      <center>
      <div>
        <h2>Experiment no 7<br></br></h2>
        <h2>Sumit Krushnat Waghmare</h2>
        <h2>Roll no:1804052</h2>
        <h2>Batch:I3</h2>
        <h2>Rajarambapu Institute of Technology</h2>
      </div></center>
    );
  }
}
 
export default Contact;