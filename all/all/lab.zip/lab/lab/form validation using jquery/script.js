jQuery('#frm').validate({
	rules:{
		name:"required",
		email:{
			required:true,
			email:true
		},
		password:{
			required:true,
			minlength:5
		},
		Phone:{
			required:true,
			minlength:10
		},
	},messages:{
		name:"Please enter your name",
		email:{
			required:"Please enter email",
			email:"Please enter valid email",
		},
		password:{
			required:"Please enter your password",
			minlength:"Password must be 5 char long"
		},
		Phone:{
			required:"Please enter your Phone",
			minlength:"Phone must be 10 char long"
		},
	},
	submitHandler:function(form){
		form.submit();
	}
});